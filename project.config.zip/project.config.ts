const ProjectPrefix = {
    APP: 'LIME',
    ENVIRONMENTS: ['development', 'production'],
} as const;

export { ProjectPrefix };
