import { database } from '~/common/database/database.js';

export default database.environmentsConfig;
