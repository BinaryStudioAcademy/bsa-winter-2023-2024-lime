enum DatabaseTableName {
    MIGRATIONS = 'migrations',
    USERS = 'users',
}

export { DatabaseTableName };
