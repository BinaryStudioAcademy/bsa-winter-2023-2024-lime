export { DatabaseTableName } from './database-table-name.enum.js';
