import { CryptService } from './crypt/crypt.service.js';

const cryptService = new CryptService();

export { cryptService };
