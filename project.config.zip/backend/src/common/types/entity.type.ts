type Entity = {
    toObject(): unknown;
    toNewObject(): unknown;
};

export { type Entity };
