import { serverApp } from '~/common/server-application/server-application.js';

await serverApp.init();
