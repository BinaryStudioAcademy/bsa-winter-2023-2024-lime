enum AuthApiPath {
    ROOT = '/',
    SIGN_UP = '/sign-up',
}

export { AuthApiPath };
