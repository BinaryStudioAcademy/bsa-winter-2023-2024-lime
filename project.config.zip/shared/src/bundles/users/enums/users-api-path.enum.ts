enum UsersApiPath {
    ROOT = '/',
}

export { UsersApiPath };
