const UserValidationRule = {
    EMAIL_MINIMUM_LENGTH: 1,
} as const;

export { UserValidationRule };
