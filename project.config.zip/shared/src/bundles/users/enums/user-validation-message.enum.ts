enum UserValidationMessage {
    EMAIL_REQUIRE = 'Email is required',
    EMAIL_WRONG = 'Email is wrong',
}

export { UserValidationMessage };
