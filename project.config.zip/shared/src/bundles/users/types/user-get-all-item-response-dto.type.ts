type UserGetAllItemResponseDto = {
    id: number;
    email: string;
};

export { type UserGetAllItemResponseDto };
