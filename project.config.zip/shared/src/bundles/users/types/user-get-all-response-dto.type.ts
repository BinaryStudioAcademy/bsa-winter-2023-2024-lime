import { type UserGetAllItemResponseDto } from './user-get-all-item-response-dto.type.js';

type UserGetAllResponseDto = {
    items: UserGetAllItemResponseDto[];
};

export { type UserGetAllResponseDto };
