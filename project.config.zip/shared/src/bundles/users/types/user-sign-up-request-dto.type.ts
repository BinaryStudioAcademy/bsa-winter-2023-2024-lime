type UserSignUpRequestDto = {
    email: string;
    password: string;
};

export { type UserSignUpRequestDto };
