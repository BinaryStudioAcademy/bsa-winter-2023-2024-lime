type UserSignUpResponseDto = {
    id: number;
    email: string;
};

export { type UserSignUpResponseDto };
