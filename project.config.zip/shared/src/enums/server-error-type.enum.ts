enum ServerErrorType {
    COMMON = 'COMMON',
    VALIDATION = 'VALIDATION',
}

export { ServerErrorType };
