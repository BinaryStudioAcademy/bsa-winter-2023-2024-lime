enum ContentType {
    JSON = 'application/json',
}

export { ContentType };
