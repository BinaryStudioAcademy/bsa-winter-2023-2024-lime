enum ApiPath {
    USERS = '/users',
    AUTH = '/auth',
}

export { ApiPath };
