enum AppEnvironment {
    LOCAL = 'local',
    DEVELOPMENT = 'development',
    PRODUCTION = 'production',
}

export { AppEnvironment };
