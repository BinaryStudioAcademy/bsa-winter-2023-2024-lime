export { configureString } from './configure-string/configure-string.helper.js';
