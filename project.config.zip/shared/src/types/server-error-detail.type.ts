type ServerErrorDetail = {
    path: (number | string)[];
    message: string;
};

export { type ServerErrorDetail };
