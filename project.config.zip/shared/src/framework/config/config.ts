export { type Config } from './types/types.js';
