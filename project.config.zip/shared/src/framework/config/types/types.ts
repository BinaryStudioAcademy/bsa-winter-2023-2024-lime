export { type Config } from './config.type.js';
