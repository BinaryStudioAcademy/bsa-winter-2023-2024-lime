type Config<T> = {
    ENV: T;
};

export { type Config };
