const HttpHeader = {
    CONTENT_TYPE: 'content-type',
    AUTHORIZATION: 'authorization',
} as const;

export { HttpHeader };
