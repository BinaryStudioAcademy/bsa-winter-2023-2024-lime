type HttpMethod = 'GET' | 'POST';

export { type HttpMethod };
