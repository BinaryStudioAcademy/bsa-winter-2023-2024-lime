export { type Storage } from './storage.type.js';
