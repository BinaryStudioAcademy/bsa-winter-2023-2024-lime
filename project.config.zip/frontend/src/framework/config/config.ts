import { BaseConfig } from './base-config.package.js';

const config = new BaseConfig();

export { config };
export { type Config } from './types/types.js';
