export { type Storage } from 'shared';
