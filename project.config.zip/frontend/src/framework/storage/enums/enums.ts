export { StorageKey } from './storage-key.enum.js';
