enum StorageKey {
    TOKEN = 'token',
}

export { StorageKey };
